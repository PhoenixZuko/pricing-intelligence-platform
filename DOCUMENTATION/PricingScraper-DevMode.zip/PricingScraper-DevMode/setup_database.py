import os
import subprocess
from dotenv import load_dotenv

# Calea către fișierul .env
env_path = os.path.join("database", ".env")

# Dacă nu există .env, creează unul default
if not os.path.exists(env_path):
    print(f"⚠️ No .env file found. Creating default one at {env_path}...")
    os.makedirs(os.path.dirname(env_path), exist_ok=True)
    with open(env_path, "w") as f:
        f.write("DB_NAME=pricing_data\n")
        f.write("DB_USER=pricing_user\n")
        f.write("DB_PASSWORD=changeme\n")
        f.write("DB_HOST=localhost\n")
        f.write("DB_PORT=5432\n")

# Încarcă variabilele din .env
load_dotenv(dotenv_path=env_path)

DB_NAME = os.getenv("DB_NAME", "pricing_data")
DB_USER = os.getenv("DB_USER", "pricing_user")
DB_PASSWORD = os.getenv("DB_PASSWORD", "changeme")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")

def is_postgres_installed():
    try:
        subprocess.run(["psql", "--version"], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False

def install_postgres():
    print("▶️ Installing PostgreSQL...")
    subprocess.run(["sudo", "apt", "update"], check=True)
    subprocess.run(["sudo", "apt", "install", "-y", "postgresql", "postgresql-contrib"], check=True)
    subprocess.run(["sudo", "systemctl", "enable", "postgresql"], check=True)
    subprocess.run(["sudo", "systemctl", "start", "postgresql"], check=True)

print("▶️ Checking PostgreSQL installation...")
if not is_postgres_installed():
    install_postgres()
else:
    print("ℹ️ PostgreSQL already installed.")

print("▶️ Using configuration:")
print(f"  DB_NAME={DB_NAME}")
print(f"  DB_USER={DB_USER}")
print(f"  DB_HOST={DB_HOST}")
print(f"  DB_PORT={DB_PORT}")

# Creează userul
print("▶️ Creating or updating user...")
subprocess.run([
    "sudo", "-u", "postgres", "psql", "-c",
    f"DO $$ BEGIN IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname='{DB_USER}') "
    f"THEN CREATE USER {DB_USER} WITH PASSWORD '{DB_PASSWORD}'; "
    f"ELSE ALTER USER {DB_USER} WITH PASSWORD '{DB_PASSWORD}'; END IF; END $$;"
], check=True)

# Creează baza de date
print("▶️ Creating database if not exists...")
result = subprocess.run([
    "sudo", "-u", "postgres", "psql", "-tAc",
    f"SELECT 1 FROM pg_database WHERE datname='{DB_NAME}'"
], capture_output=True, text=True)

if result.stdout.strip() != "1":
    subprocess.run([
        "sudo", "-u", "postgres", "createdb", "-O", DB_USER, DB_NAME
    ], check=True)
    print(f"✅ Database '{DB_NAME}' created with owner '{DB_USER}'.")
else:
    print(f"ℹ️ Database '{DB_NAME}' already exists.")
