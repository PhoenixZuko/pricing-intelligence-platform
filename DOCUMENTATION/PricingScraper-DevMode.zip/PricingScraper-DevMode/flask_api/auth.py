from flask_httpauth import HTTPBasicAuth
import os
from dotenv import load_dotenv
from pathlib import Path

# load doar fisierul .env din flask_api
load_dotenv(Path(__file__).resolve().parent / ".env")

auth = HTTPBasicAuth()
USER = os.getenv("API_USER")
PASS = os.getenv("API_PASS")

@auth.verify_password
def verify(username, password):
    return username == USER and password == PASS
