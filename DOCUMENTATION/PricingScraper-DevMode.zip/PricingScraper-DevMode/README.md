# 📂 Project Structure Overview

├── archive/ # Stores old results_data_* folders (cleaned by utils/cleaner.py)
│ ├── results_data_23_09_2025/ # Archived output from a specific run (CSV/JSON files)
│ └── results_data_24_09_2025/ # Same as above, for another date
│
├── category_parser/ # Adds categories/types to scraped data
│ ├── create_category.py # Script for parsing categories
│ ├── create_type.py # Script for parsing types
│ ├── output_data_with_type.csv # Example enriched output
│ └── type_definitions/ # YAML files with category/type rules
│
├── config.yaml # Central configuration for scrapers and pipeline
│
├── database/ # Database initialization and schema
│ ├── db_setup.py # Creates tables and indexes in PostgreSQL
│ └── README.md # Documentation for database setup
│
├── documentation/ # Extra documentation
│ ├── README_Fasted.md # Quick start guide
│ ├── README.md # Full documentation
│ └── requirements.txt # Dependencies for docs
│
├── flask_api/ # REST API for exposing DB data
│ ├── app.py # Main Flask app (routes /api, /site/<name>)
│ ├── auth.py # Authentication (Basic Auth)
│ ├── db.py # SQLAlchemy DB connection
│ ├── README.md # API usage guide
│ └── requirements.txt # Dependencies for the API
│
├
│
├── install_and_run.py # Automatic installer (deps + DB + run pipeline)
├── INSTALL.md # Installation instructions
├── README.md # General project documentation
├── requirements.txt # Main Python dependencies
├── runner.py # Orchestrator (runs scrapers, processors, DB insert)
│
├── Scrapers/ # All scraping scripts and helpers
│ ├── 1cdz-scraper.py # Individual scraper (site-specific)
│ ├── 2dino-scraper.py # Another scraper
│ ├── 3klebs-scraper.py # Another scraper
│ ├── 4main_clearago.py # Another scraper
│ ├── 5main_entsorgo.py # Another scraper
│ ├── core_clearago/ # Helper modules for clearago scraper
│ │ ├── details_scraper.py # Extracts details from pages
│ │ ├── format_csv.py # Formats output to CSV
│ │ ├── homepage.py # Homepage scraper
│ │ └── waste_categories.py # Category definitions for clearago
│ ├── core_ensorgo/ # Helper modules for entsorgo scraper
│ │ └── scraper.py # Extractor for entsorgo
│ ├── cvs_maker.py # Generates CSV output from raw data
│ ├── json_maker.py # Generates JSON output
│ ├── README.md # Documentation for scrapers
│ ├── results_cdz-berlin/ # Example results for cdz scraper
│ └── results_dino_container/ # Example results for dino scraper
│
└── utils/ # Automation and housekeeping tools
├── cleaner.py # Moves results to archive and deletes >7 days old
├── setup_cron.py # Installs cron job for runner.py (every 10 days at 06:00)
├── setup_api_service.py # Installs Flask API as a systemd service
└── README.md # Documentation for utils





# 🛠 Runner Workflow (Pipeline Overview)

This document explains the full process handled by `runner.py`.

---

## 📊 Pipeline Diagram (ASCII)

+------------------+
|   runner.py      |
| (Start process)  |
+--------+---------+
         |
         v
+------------------+
| Load config.yaml |
+--------+---------+
         |
         v
+----------------------------+
| Run enabled scrapers       |
| from Scrapers/ (per config)|
+--------+-------------------+
         |
         v
+----------------------------+
| Run formatters             |
| - json_maker.py            |
| - cvs_maker.py             |
+--------+-------------------+
         |
         v
+----------------------------+
| Run category parsers       |
| - create_type.py           |
| - create_category.py       |
+--------+-------------------+
         |
         v
+----------------------------+
| Insert into PostgreSQL     |
| via database/db_setup.py   |
+--------+-------------------+
         |
         v
+----------------------------+
| Run cleaner.py             |
| (move results_data_* →     |
|  archive/, delete >7 days) |
+--------+-------------------+
         |
         v
+------------------+
|   Process End    |
+------------------+

---

## ✅ Step Explanation

1. **Load configuration**  
   - Reads `config.yaml` to see which scrapers are enabled.  

2. **Run scrapers**  
   - Executes only the scripts with `enabled: true` in `Scrapers/`.  

3. **Run formatters**  
   - Standardizes output by creating `output_data.json` and `output_data.csv`.  

4. **Run category parsers**  
   - Enriches data with `type` and `category` using YAML definitions.  

5. **Insert into database**  
   - Calls `database/db_setup.py` to insert/update data in PostgreSQL.  

6. **Cleaner step**  
   - Runs `utils/cleaner.py` to archive old results and clean data older than 7 days.  

---

➡️ This makes `runner.py` the **orchestrator**: it runs scrapers, processes results, loads them into the database, and cleans up old data automatically.  



# 📂 Project Structure Overview

This project is organized into modules that handle scraping, data processing, storage, and API access.  
Below is a high-level overview of the folders and their purpose.

---

## 🔹 Root Files
- **README.md / INSTALL.md** → Main documentation and installation guide.  
- **requirements.txt** → Python dependencies for the project.  
- **runner.py** → Main entry point; orchestrates scrapers, processing, and DB insertion.  
- **install_and_run.py** → Automatic installer: installs dependencies, sets up DB, and runs the pipeline.  
- **flask_api.service** → Systemd service definition for running the Flask API automatically.  
- **config.yaml** → Central configuration file for scrapers and pipeline behavior.  

---

## 🔹 archive/
Stores historical results moved by the `cleaner.py` script.  
Each folder contains CSV and JSON outputs of a scraping run, kept for backup.  

---

## 🔹 Scrapers/
Contains all web scrapers and helper scripts.  
- **X-scraper.py** → Individual scrapers (e.g., cdz, dino, klebs, etc.).  
- **core_clearago/** & **core_ensorgo/** → Internal modules for handling specific websites.  
- **cvs_maker.py / json_maker.py** → Formatters that generate standardized CSV and JSON files.  
- **results_* folders** → Store raw results from scraper runs.  

---

## 🔹 category_parser/
Responsible for classifying scraped data into categories and types.  
- **create_category.py / create_type.py** → Parsing and enrichment scripts.  
- **type_definitions/** → YAML files defining waste categories and types.  
- **output_data_with_type.csv** → Example processed output with categories/types.  

---

## 🔹 database/
Handles database initialization and structure.  
- **setup_database.py** (root-level helper) → Creates database and user from `.env`.  
- **db_setup.py** → Creates required tables and indexes (`scraped_data`).  
- **README.md** → Documentation for DB setup.  

---

## 🔹 utils/
Helper scripts for automation and housekeeping.  
- **cleaner.py** → Moves result folders into `archive/` and deletes archives older than 7 days.  
- **setup_cron.py** → Installs cron job for automatic execution of `runner.py`.  
- **setup_api_service.py** → Registers Flask API as a systemd service.  
- **README.md** → Documentation for utilities.  

---

## 🔹 flask_api/
Flask-based API exposing the scraped data.  
- **app.py** → Main API application with routes.  
- **auth.py** → Authentication logic (Basic Auth).  
- **db.py** → SQLAlchemy integration with PostgreSQL.  
- **requirements.txt** → Dependencies for the API.  
- **README.md** → API documentation.  

---

## 🔹 documentation/
Contains additional documentation and requirements for developers.  
- **README.md / README_Fasted.md** → Extended and quick-start documentation.  
- **requirements.txt** → Dependencies for documentation-related tooling.  

---

# ✅ Summary
- **Scrapers/** → Collect raw data from websites.  
- **category_parser/** → Adds categories/types to scraped data.  
- **database/** → Stores data in PostgreSQL.  
- **utils/** → Automation tools (cron, cleaning, services).  
- **flask_api/** → Exposes data through an authenticated REST API.  
- **archive/** → Stores historical results.  
- **runner.py** → Orchestrates the entire workflow.  




# 🚀 Quick Install Summary

Follow these steps to set up the project.  
For **detailed step-by-step instructions**, please read [INSTALL.md](./INSTALL.md).

---

## 🔹 Steps Overview

1. **Configure Database**
   - Go to `database/` and edit `.env` (set DB name, user, password).
   - Run:
     ```bash
     sudo python3 setup_database.py
     ```

2. **Install & Run**
   - From project root:
     ```bash
     python3 install_and_run.py
     ```
   - Installs dependencies, sets up DB tables, runs scrapers.

3. **Run Manually**
   - To launch the full pipeline manually:
     ```bash
     python3 runner.py
     ```

4. **Configure Cronjobs (optional)**
   - Example: run daily at 00:00
     ```bash
     echo "0 0 * * * /usr/bin/python3 /path/to/project/runner.py >> /path/to/project/cron.log 2>&1" | crontab -
     ```
   - Other schedules available in `INSTALL.md`.

5. **Enable API Service**
   - Go to `flask_api/`, edit `.env` (set API_USER and API_PASS).
   - Install systemd service:
     ```bash
     sudo python3 utils/setup_api_service.py
     ```
   - Access API:
     ```
     http://SERVER_IP:3101/api
     ```

---

## 📌 Final Note
This is the **development (dev) version** of the project.  
It is intended for **manual step-by-step installation**, so it can be reused or reconfigured later.  
For full details, troubleshooting, and explanations, see **INSTALL.md**.

