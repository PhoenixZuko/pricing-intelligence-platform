import subprocess
import os
from dotenv import load_dotenv

def install_requirements():
    print("▶️ Installing dependencies from requirements.txt...")
    subprocess.run(["python3", "-m", "pip", "install", "-r", "requirements.txt"], check=True)

def install_playwright_deps():
    print("▶️ Installing Playwright native dependencies (Ubuntu 24.04 fix)...")
    try:
        subprocess.run(["python3", "-m", "playwright", "install-deps"], check=True)
    except subprocess.CalledProcessError:
        print("⚠️ Falling back to manual dependency install for Ubuntu 24.04...")
        subprocess.run([
            "sudo", "apt", "install", "-y",
            "libasound2t64", "libatk-bridge2.0-0t64", "libatk1.0-0t64",
            "libatspi2.0-0t64", "libcups2t64", "libglib2.0-0t64",
            "libgtk-3-0t64", "libpng16-16t64", "libevent-2.1-7t64",
            "libicu74", "libffi8"
        ], check=True)

def install_playwright_browsers(retries=3):
    print("▶️ Installing Playwright browsers...")
    for attempt in range(1, retries + 1):
        try:
            subprocess.run(["python3", "-m", "playwright", "install"], check=True)
            print("✅ Playwright browsers installed successfully")
            return
        except subprocess.CalledProcessError as e:
            print(f"⚠️ Attempt {attempt} failed: {e}")
            if attempt == retries:
                print("❌ Could not install Playwright browsers after multiple attempts.")
                exit(1)
            else:
                print("⏳ Retrying...")


def load_env():
    env_path = os.path.join("database", ".env")
    load_dotenv(dotenv_path=env_path)
    return {
        "DB_NAME": os.getenv("DB_NAME", "webscraper_db"),
        "DB_USER": os.getenv("DB_USER", "postgres"),
        "DB_PASSWORD": os.getenv("DB_PASSWORD", ""),
        "DB_HOST": os.getenv("DB_HOST", "localhost"),
        "DB_PORT": os.getenv("DB_PORT", "5432"),
    }

def ensure_database_exists(config):
    import psycopg2
    try:
        conn = psycopg2.connect(
            dbname='postgres',
            user=config["DB_USER"],
            password=config["DB_PASSWORD"],
            host=config["DB_HOST"],
            port=config["DB_PORT"]
        )
        conn.autocommit = True
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM pg_database WHERE datname = %s", (config["DB_NAME"],))
        exists = cursor.fetchone()
        if not exists:
            print(f"📦 Creating database: {config['DB_NAME']}")
            cursor.execute(f"CREATE DATABASE {config['DB_NAME']};")
        else:
            print(f"✅ Database '{config['DB_NAME']}' already exists.")
        cursor.close()
        conn.close()
    except Exception as e:
        print(f"❌ Error connecting to PostgreSQL: {e}")
        print("❗ Check your .env credentials before continuing.")
        exit(1)

def run_db_setup():
    print("▶️ Running db_setup.py...")
    subprocess.run(["python3", "database/db_setup.py"], check=True)

if __name__ == "__main__":
    install_requirements()
    install_playwright_deps()
    install_playwright_browsers()
    config = load_env()
    ensure_database_exists(config)
    run_db_setup()
