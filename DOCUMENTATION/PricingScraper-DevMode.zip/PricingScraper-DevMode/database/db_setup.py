import os
import sys
import psycopg2
import pandas as pd
from dotenv import load_dotenv

# Încarcă variabilele din .env
load_dotenv()

DB_NAME = os.getenv("DB_NAME")
DB_USER = os.getenv("DB_USER")
DB_PASSWORD = os.getenv("DB_PASSWORD")
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT")

# Verifică toate folderele results_data_*
root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
csv_folders = [f for f in os.listdir(root_dir) if f.startswith("results_data_") and os.path.isdir(os.path.join(root_dir, f))]

if not csv_folders:
    print("❌ There is no results_data_* folder.")
    sys.exit()

# Caută toate fișierele output_data_with_category.csv
csv_paths = []
for folder in csv_folders:
    file_path = os.path.join(root_dir, folder, "output_data_with_category.csv")
    if os.path.exists(file_path):
        csv_paths.append(file_path)

if not csv_paths:
    print("❌ CSV file not found in any results_data_* folder.")
    sys.exit()

print(f"✅ Found {len(csv_paths)} CSV file(s).")

# Citește și concatenează datele din toate fișierele
try:
    df_list = [pd.read_csv(p) for p in csv_paths]
    df = pd.concat(df_list, ignore_index=True)

    df.rename(columns={
        "date": "scraped_at",
        "link": "site",
        "kubikmeter": "volume",
        "produkt": "product"
    }, inplace=True)

    df["scraped_at"] = pd.to_datetime(df["scraped_at"])
    print(f"✅ Total rows before filtering: {len(df)}")

except Exception as e:
    print("❌ Failed to read or process CSVs:", e)
    sys.exit()

# Conectare la PostgreSQL
try:
    conn = psycopg2.connect(
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        host=DB_HOST,
        port=DB_PORT
    )
    cursor = conn.cursor()
    print("✅ Connected to PostgreSQL.")
except Exception as e:
    print("❌ Error connecting to the database:", e)
    sys.exit()

# Creează tabela dacă nu există
create_table_query = """
CREATE TABLE IF NOT EXISTS scraped_data (
    id SERIAL PRIMARY KEY,
    scraped_at TIMESTAMP,
    site TEXT,
    volume FLOAT,
    product TEXT,
    currency TEXT,
    price FLOAT,
    type TEXT,
    category TEXT,
    subcategory TEXT
);
"""

create_unique_index = """
CREATE UNIQUE INDEX IF NOT EXISTS unique_entry_per_day
ON scraped_data (DATE(scraped_at), site, volume, product);
"""

try:
    cursor.execute(create_table_query)
    cursor.execute(create_unique_index)
    conn.commit()
    print("✅ Table and unique index checked/created.")
except Exception as e:
    print("❌ Failed to create table or index:", e)
    conn.rollback()
    cursor.close()
    conn.close()
    sys.exit()

# Găsește ziua maximă (ultima zi din date)
current_day = df["scraped_at"].dt.date.max()
if pd.isna(current_day):
    print("❌ Error: No valid date found in scraped_at column.")
    sys.exit()

# Șterge datele existente din aceeași zi
try:
    delete_query = "DELETE FROM scraped_data WHERE DATE(scraped_at) = %s;"
    cursor.execute(delete_query, (current_day,))
    conn.commit()
    print(f"✅ Deleted existing data for date: {current_day}")
except Exception as e:
    print("❌ Failed to delete old data for current day:", e)
    conn.rollback()
    cursor.close()
    conn.close()
    sys.exit()

# Inserare date
insert_query = """
INSERT INTO scraped_data (
    scraped_at, site, volume, product, currency, price, type, category, subcategory
)
VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
ON CONFLICT DO NOTHING;
"""

try:
    for _, row in df.iterrows():
        cursor.execute(insert_query, (
            row["scraped_at"],
            row["site"],
            row["volume"],
            row["product"],
            row["currency"],
            row["price"],
            row.get("type", None),
            row.get("category", None),
            row.get("subcategory", None)
        ))
    conn.commit()
    print("✅ Data inserted successfully (duplicates skipped by constraint).")
except Exception as e:
    print("❌ Failed to insert data:", e)
    conn.rollback()

cursor.close()
conn.close()
