📌 First Read

This repository contains the development version (Dev) of the project.
It is designed for manual step-by-step installation, allowing developers to follow a semi-automated process with clear and safe steps.

🔹 Use this version if you need flexibility, debugging, or future modifications.
🔹 The final production version will be delivered with Docker and Metabase integration for fully automated deployment.

In this Dev version:

All installation steps are split into small, verifiable tasks.
Scripts handle automation where possible, but manual control is preserved.
Ideal for development, testing, or environments where Docker is not desired.

📖 Documentation

The main installation guide is in INSTALL.md (detailed step-by-step setup).
The top-level README.md explains the project structure and usage.
Each folder contains its own README.md, describing the role of that module and the functionality of individual programs.

👉 Start with README.md for the big picture, then check INSTALL.md for installation, and use per-folder READMEs for details.

