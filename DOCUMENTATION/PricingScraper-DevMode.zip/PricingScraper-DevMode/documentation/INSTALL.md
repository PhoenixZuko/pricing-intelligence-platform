-------------------------------------------------
Final Note
-------------------------------------------------
This project is designed for **manual installation step by step**, so it can be reused whenever future modifications or reconfigurations are required. It represents the **development (dev) version** of the project.
👉 Totul e acum într-un singur bloc mare, inclusiv cu nota finală. Îți e bun așa sau vrei să-ți fac și o variantă

# 📄 Setup & Usage Guide
-------------------------------------------------
Step 1 – Configure the .env file in database/
-------------------------------------------------
cd database
nano .env

⚠️ Important: Do not change the left side of '=' (DB_NAME, DB_USER, DB_PASSWORD, DB_HOST, DB_PORT). Only edit the values on the right side.

Example:
DB_NAME=pricing_data
DB_USER=pricing_user
DB_PASSWORD=StrongPass2025
DB_HOST=localhost
DB_PORT=5432

Passwords should avoid special characters (=, :, ;, ", ', \, spaces). Allowed: A–Z, a–z, 0–9, _, -.

-------------------------------------------------
Step 2 – Create the Database
-------------------------------------------------
sudo python3 setup_database.py

Expected output:
Using configuration:
 DB_NAME=eexxsss_data
 DB_USER=eexxsss_user
 DB_HOST=localhost
 DB_PORT=5432
Creating or updating user...
DO
Creating database if not exists...
Database 'eexxsss_data' created with owner 'eexxsss_user'.

Verify connection:
psql -h localhost -U eexxsss_user -d eexxsss_data

-------------------------------------------------
Step 3 – Run install_and_run.py
-------------------------------------------------
python3 install_and_run.py

This script:
- Installs Python libraries (requirements.txt)
- Installs Playwright dependencies and browsers
- Reads database/.env
- Creates the database if not present
- Runs database/db_setup.py to create scraped_data table

If errors about missing libraries appear (e.g. libicu70, libasound2), install manually:
sudo apt-get update
sudo apt-get install -y libnss3 libxcomposite1 libxdamage1 libxfixes3 \
  libxrandr2 libgbm1 libpango-1.0-0 libpangocairo-1.0-0 \
  libasound2t64 libatk-bridge2.0-0t64 libatk1.0-0t64 \
  libatspi2.0-0t64 libcups2t64 libglib-2.0-0t64 \
  libgtk-3-0t64 libpng16-16t64 libevent-2.1-7t64

Then rerun:
python3 install_and_run.py

-------------------------------------------------
Step 4 – Run the Program
-------------------------------------------------
From project root:
python3 runner.py

What it does:
- Sets a cronjob (default: every 10 days)
- Runs scrapers from config.yaml
- Creates CSV and JSON in results_data_YYYY_MM_DD/
- Runs category/type parsers
- Inserts into PostgreSQL
- Runs cleaner.py (moves results, cleans temp folders)

Example output:
Cronjob set: program runs automatically every 10 days at 00:00.
Now Running: 1cdz-scraper.py
[SAVED] Product: Bauschutt | Size: 6 | Price: 471,00 €
Final JSON saved: output_data.json
Final CSV saved: output_data.csv
Data inserted successfully (duplicates skipped by constraint).
Cleaner finished successfully.

Note:
- Running multiple times in the same day updates data (no duplicates).
- On a new day, new records are created.
- Cronjob keeps program running automatically.

-------------------------------------------------
Step 5 – Configure Cronjobs
-------------------------------------------------
# ▶ Run DAILY at 00:00 (every day)
echo "0 0 * * * /usr/bin/python3 /path/to/project/runner.py >> /path/to/project/cron.log 2>&1" | crontab -

# ▶ Run EVERY 2 DAYS at 00:00  
echo "0 0 */2 * * /usr/bin/python3 /path/to/project/runner.py >> /path/to/project/cron.log 2>&1" | crontab -

# ▶ Run EVERY 7 DAYS at 00:00 (best practice: once a week, every Monday)
echo "0 0 * * 1 /usr/bin/python3 /path/to/project/runner.py >> /path/to/project/cron.log 2>&1" | crontab -
# (If you really want "*/7" on the day-of-month field: echo "0 0 */7 * * ..." | crontab -
#   → ⚠ not exactly every 7 days, depends on month length)

# ▶ Run EVERY 30 DAYS at 00:00 (best practice: first day of each month)
echo "0 0 1 * * /usr/bin/python3 /path/to/project/runner.py >> /path/to/project/cron.log 2>&1" | crontab -
# (If you insist on "*/30" in the day-of-month field: echo "0 0 */30 * * ..." | crontab -
#   → ⚠ may be irregular because months have 28–31 days)


-------------------------------------------------
Step 6 – Enable the API Service
-------------------------------------------------
cd flask_api
nano .env

Set values:
FLASK_SECRET_KEY=secret123
API_USER=admin
API_PASS=YourPassword

⚠️ Do not change the left side (API_USER=, API_PASS=). Only edit values.

cd ../utils
sudo python3 setup_api_service.py

Check service:
systemctl status flask_api.service

API will be available at:
http://SERVER_IP:3101/api

Expected confirmation:
API service installed and running on port 3101

Note: In Docker setup, this step is not required (handled by container and Traefik).


-------------------------------------------------
Final Note
-------------------------------------------------
This project is designed for **manual installation step by step**, so it can be reused whenever future modifications or reconfigurations are required. It represents the **development (dev) version** of the project.
