# utils/setup_cron.py
import subprocess
import os

def main():
    project_path = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    runner_path = os.path.join(project_path, "runner.py")

    # Program standard: la fiecare 10 zile, ora 06:00
    cron_command = f"0 6 */10 * * /usr/bin/python3 {runner_path}\n"

    try:
        existing = subprocess.getoutput("crontab -l")
        if runner_path in existing:
            print("ℹ️ Cron job already exists for runner.py")
            return

        new_crontab = existing + "\n" + cron_command if existing else cron_command
        subprocess.run("crontab -", input=new_crontab.encode(), shell=True, check=True)
        print("✅ Cron job installed successfully.")
        print("📅 This program is now set to update every 10 days at 06:00.")
    except Exception as e:
        print(f"❌ Error setting cron job: {e}")

if __name__ == "__main__":
    main()
